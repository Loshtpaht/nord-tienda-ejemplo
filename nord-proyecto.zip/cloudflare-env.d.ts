declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    ADMIN_EMAILS?: string;
    RESEND_API_KEY?: string;
    MAIL_FROM?: string;
    OPENAI_API_KEY?: string;
    OPENAI_MODEL?: string;
    MAINTENANCE_TOKEN?: string;
  }
}

declare namespace Cloudflare { interface Env { AUTH_SECRET?: string; } }

declare namespace Cloudflare { interface Env { INITIAL_PROVIDER_EMAIL?: string; INITIAL_PROVIDER_PRODUCTS?: string; } }
