import {NextResponse} from 'next/server';
export function proxy(request: Request){
 const response=NextResponse.next();
 response.headers.set('X-Content-Type-Options','nosniff');
 response.headers.set('Referrer-Policy','same-origin');
 response.headers.set('Permissions-Policy','camera=(), microphone=(), geolocation=()');
 const dev=process.env.NODE_ENV!=='production';
 response.headers.set('X-Robots-Tag','noindex, nofollow');
 if(!dev&&new URL(request.url).protocol==='https:')response.headers.set('Strict-Transport-Security','max-age=31536000; includeSubDomains');
 response.headers.set('Content-Security-Policy',`default-src 'self'; script-src 'self' 'unsafe-inline'${dev?" 'unsafe-eval'":''}; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'${dev?' ws: wss:':''}; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self' https://chatgpt.com https://*.chatgpt.com https://chat.openai.com`);
 return response;
}
export const config={matcher:['/((?!_next|assets|images|fonts).*)']};
