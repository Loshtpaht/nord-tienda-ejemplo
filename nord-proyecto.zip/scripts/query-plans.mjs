import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';

const db=new DatabaseSync(':memory:');
for(const name of ['0000_lazy_trauma','0001_hard_jimmy_woo','0002_early_hawkeye']){
 db.exec(readFileSync(new URL(`../drizzle/${name}.sql`,import.meta.url),'utf8'));
}
const queries={
 expiry:"SELECT id FROM orders WHERE status='recibido' AND expires<=unixepoch()",
 variantByProduct:"SELECT * FROM variants WHERE product_id='camisa-lino'",
 orderLines:'SELECT * FROM order_lines WHERE order_id=1',
 orderKey:"SELECT id FROM orders WHERE order_key='abc'",
 recentOrders:'SELECT * FROM orders ORDER BY id DESC LIMIT 300',
 recentAudit:'SELECT * FROM audit ORDER BY id DESC LIMIT 300',
 session:"SELECT * FROM auth_sessions WHERE token_hash='abc' AND expires>unixepoch()"
};
function plans(){return Object.fromEntries(Object.entries(queries).map(([name,sql])=>[name,db.prepare('EXPLAIN QUERY PLAN '+sql).all().map(row=>row.detail)]));}
const before=plans();
db.exec(readFileSync(new URL('../drizzle/0003_aberrant_bulldozer.sql',import.meta.url),'utf8'));
console.log(JSON.stringify({before,after:plans()},null,2));
