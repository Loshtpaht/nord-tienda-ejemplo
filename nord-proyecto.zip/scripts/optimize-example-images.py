"""Create smaller WebP copies of the four large example images.

Run manually with Pillow installed; these files are committed and are not
generated during the application build.
"""
from pathlib import Path
from PIL import Image, ImageOps

root = Path(__file__).resolve().parents[1] / "public" / "images"
for name in ("hero", "trousers", "armani", "boss"):
    with Image.open(root / f"{name}.png") as image:
        image.save(root / f"{name}.webp", "WEBP", quality=86, method=6)
        if name == "hero":
            preview = ImageOps.fit(image, (1200, 630), method=Image.Resampling.LANCZOS)
            preview.save(root.parent / "og-nord.jpg", "JPEG", quality=84, optimize=True)
