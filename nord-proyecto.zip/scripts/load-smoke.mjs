// Prueba de lectura, acotada a loopback para no generar tráfico ni costos externos.
const url = new URL(process.argv[2] || 'http://127.0.0.1:8787/api/catalog');
if (!['127.0.0.1', 'localhost'].includes(url.hostname) || url.pathname !== '/api/catalog') {
  throw new Error('La prueba solo admite /api/catalog en este equipo.');
}
const percentile = (sorted, fraction) => sorted[Math.min(sorted.length - 1, Math.ceil(sorted.length * fraction) - 1)];
for (const concurrency of [1, 10, 25, 50]) {
  const total = 100;
  let next = 0;
  const timings = [];
  const errors = [];
  const started = performance.now();
  await Promise.all(Array.from({length: concurrency}, async () => {
    while (next < total) {
      next++;
      const at = performance.now();
      try {
        const response = await fetch(url, {headers: {'Cache-Control': 'no-cache'}});
        if (!response.ok) errors.push(response.status);
        await response.arrayBuffer();
      } catch (error) {
        errors.push(String(error));
      }
      timings.push(performance.now() - at);
    }
  }));
  timings.sort((a, b) => a - b);
  console.log(JSON.stringify({concurrency, requests: total, p50Ms: Math.round(percentile(timings, .5)), p95Ms: Math.round(percentile(timings, .95)), errors: errors.length, elapsedMs: Math.round(performance.now() - started)}));
}
