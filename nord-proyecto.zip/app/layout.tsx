import type { Metadata } from "next";
import "./globals.css";
import {CookiePreferences} from "./cookies";

export const metadata: Metadata = {
  title: "NÓRD · Moda y fragancias · Tienda de ejemplo",
  description: "Ropa, fragancias y detalles para tu día a día. Pedidos sin pago en línea.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{__html:"try{document.documentElement.dataset.theme=(JSON.parse(localStorage.getItem('nord-consent')||'null')?.preferences&&JSON.parse(localStorage.getItem('nord-consent')||'null')?.expires>Date.now()?localStorage.getItem('nord-theme'):null)||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light')}catch{}"}}/></head>
      <body>{children}<CookiePreferences/></body>
    </html>
  );
}
