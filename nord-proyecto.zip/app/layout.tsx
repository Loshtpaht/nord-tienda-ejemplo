import type { Metadata } from "next";
import "./globals.css";
import {CookiePreferences} from "./cookies";

export const metadata: Metadata = {
  title: "NÓRD · Moda y fragancias · Tienda de ejemplo",
  description: "Explora ropa, fragancias y accesorios de ejemplo de NÓRD. Demo sin ventas ni pagos reales.",
  robots: { index: false, follow: false },
  openGraph: {
    type: "website",
    locale: "es_SV",
    siteName: "NÓRD · Tienda de ejemplo",
    title: "NÓRD · Moda y fragancias",
    description: "Catálogo de demostración de ropa, fragancias y accesorios. Sin ventas ni pagos reales.",
    images: [{ url: "/og-nord.jpg", width: 1200, height: 630, alt: "NÓRD, tienda de ejemplo de moda y fragancias" }],
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{__html:"try{document.documentElement.dataset.theme=(JSON.parse(localStorage.getItem('nord-consent')||'null')?.preferences&&JSON.parse(localStorage.getItem('nord-consent')||'null')?.expires>Date.now()?localStorage.getItem('nord-theme'):null)||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light')}catch{}"}}/></head>
      <body>{children}<CookiePreferences/></body>
    </html>
  );
}
