'use client';
import {useEffect,useRef,useState,ReactNode} from 'react';
import {Sun,Moon,X} from 'lucide-react';
export const money=(n:number)=>new Intl.NumberFormat('es-SV',{style:'currency',currency:'USD'}).format(n/100);
export async function api(path:string,data?:any):Promise<any>{
 let response:Response;
 try{response=await fetch('/api/'+path,{method:data===undefined?'GET':'POST',headers:data===undefined?undefined:{'Content-Type':'application/json'},body:data===undefined?undefined:JSON.stringify(data)});}
 catch{throw Error('No hay conexión con la tienda. Comprueba tu conexión e inténtalo de nuevo.');}
 let result:any;
 try{result=await response.json();}
 catch{throw Error('La tienda no respondió correctamente. Inténtalo de nuevo en unos minutos.');}
 if(!response.ok)throw Error(typeof result?.error==='string'?result.error:'No se pudo completar la solicitud.');
 return result;
}
export function ThemeButton(){const [dark,setDark]=useState(false);useEffect(()=>{setDark(document.documentElement.dataset.theme==='dark');const m=matchMedia('(prefers-color-scheme: dark)');const update=()=>{if(!localStorage.getItem('nord-theme')){document.documentElement.dataset.theme=m.matches?'dark':'light';setDark(m.matches)}};m.addEventListener('change',update);return()=>m.removeEventListener('change',update)},[]);return <button className="icon-button" title={dark?'Cambiar a modo claro':'Cambiar a modo oscuro'} aria-label={dark?'Cambiar a modo claro':'Cambiar a modo oscuro'} onClick={()=>{const t=dark?'light':'dark';document.documentElement.dataset.theme=t;try{const c=JSON.parse(localStorage.getItem('nord-consent')||'null');if(c?.preferences&&c.expires>Date.now())localStorage.setItem('nord-theme',t)}catch{}setDark(!dark)}}>{dark?<Sun size={20}/>:<Moon size={20}/>}</button>}
export function Modal({title,children,onClose,wide=false}:{title:string;children:ReactNode;onClose:()=>void;wide?:boolean}){const ref=useRef<HTMLDialogElement>(null);useEffect(()=>{const d=ref.current!;d.showModal();const previous=document.body.style.overflow;document.body.style.overflow='hidden';return()=>{d.close();document.body.style.overflow=previous}},[]);return <dialog ref={ref} className={wide?'modal wide':'modal'} onCancel={e=>{e.preventDefault();onClose()}} onClick={e=>{if(e.target===ref.current)onClose()}} aria-label={title}><header className="modal-header"><h2>{title}</h2><button className="icon-button" onClick={onClose} aria-label="Cerrar"><X size={22}/></button></header>{children}</dialog>}
export function ErrorBox({text}:{text:string}){return text?<p className="error" role="alert">{text}</p>:null;}

