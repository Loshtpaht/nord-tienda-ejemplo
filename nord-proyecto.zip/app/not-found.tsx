import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Página no encontrada · NÓRD",
  description: "La dirección solicitada no existe. Vuelve al catálogo de ejemplo de NÓRD.",
  robots: { index: false, follow: false },
};

export default function NotFound() {
  return <main className="not-found-page">
    <p className="eyebrow">NÓRD · Error 404</p>
    <h1>Esta página no está aquí.</h1>
    <p>Comprueba el enlace o vuelve a explorar el catálogo de ejemplo.</p>
    <Link className="primary" href="/">Volver a la tienda</Link>
  </main>;
}
