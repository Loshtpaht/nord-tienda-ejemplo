import LegalPage from './view';
export default async function Page({params}:{params:Promise<{page:string}>}){const {page}=await params;return <LegalPage page={page}/>}
