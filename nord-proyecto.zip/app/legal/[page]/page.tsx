import LegalPage from './view';
import {notFound} from 'next/navigation';
import type {Metadata} from 'next';
import {legalNames} from '../../../lib/legal.mjs';
const names=legalNames as Record<string,string>;
export async function generateMetadata({params}:{params:Promise<{page:string}>}):Promise<Metadata>{
 const {page}=await params;
 if(!Object.hasOwn(names,page))return {title:'Página no encontrada · NÓRD',robots:{index:false,follow:false}};
 return {
  title:`${names[page]} · NÓRD`,
  description:`${names[page]} de NÓRD, tienda de ejemplo en El Salvador. Borrador sujeto a datos del operador y revisión legal.`,
  robots:{index:false,follow:false},
  openGraph:{title:`${names[page]} · NÓRD`,description:'Información de la tienda de ejemplo NÓRD en El Salvador.',images:[{url:'/og-nord.jpg',width:1200,height:630}]},
 };
}
export default async function Page({params}:{params:Promise<{page:string}>}){const {page}=await params;if(!Object.hasOwn(names,page))notFound();return <LegalPage page={page}/>}
