export default function Loading() {
  return <main className="loading-page" role="status" aria-live="polite">
    <span className="wordmark">NÓRD</span>
    <div className="skeleton hero-skeleton" aria-hidden="true" />
    <p>Cargando la tienda…</p>
  </main>;
}
