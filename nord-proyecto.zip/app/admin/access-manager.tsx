'use client';
import {useState} from 'react';

const ORDER_PERMISSION='@manage-orders';
const assigned=(entry:any):string[]=>JSON.parse(entry.products);

export default function AccessManager({data,onSave,busy}:{data:any;onSave:(x:any)=>Promise<any>;busy:boolean}){
 const [email,setEmail]=useState('');
 const [products,setProducts]=useState<string[]>([]);
 const [manageOrders,setManageOrders]=useState(false);
 const reset=()=>{setEmail('');setProducts([]);setManageOrders(false)};
 return <>
  <h2>Accesos de la tienda</h2>
  <p className="muted">El acceso al inventario se limita a los productos asignados. Puedes conceder por separado permiso para ver y gestionar pedidos; ese permiso incluye los datos de contacto y entrega del cliente. Solo las cuentas administradoras ven configuración, correos y otros accesos.</p>
  <form className="settings-form" onSubmit={async e=>{e.preventDefault();if(await onSave({email,products,manageOrders,active:true}))reset()}}>
   <label>Correo de la persona autorizada<input type="email" required maxLength={254} autoComplete="off" value={email} onChange={e=>setEmail(e.target.value)}/></label>
   <fieldset className="access-products"><legend>Productos que podrá actualizar</legend>{data.products.filter((p:any)=>p.active).map((p:any)=><label className="checkbox" key={p.id}><input type="checkbox" checked={products.includes(p.id)} onChange={e=>setProducts(e.target.checked?[...products,p.id]:products.filter(id=>id!==p.id))}/>{p.name}</label>)}</fieldset>
   <label className="checkbox"><input type="checkbox" checked={manageOrders} onChange={e=>setManageOrders(e.target.checked)}/><span>Permitir ver, confirmar y cancelar pedidos y contactar al cliente</span></label>
   <button className="primary" disabled={busy||!products.length}>{busy?'Guardando…':'Guardar permisos'}</button>
  </form>
  <div className="table-wrap"><table><caption>Cuentas autorizadas</caption><thead><tr><th>Correo</th><th>Productos asignados</th><th>Pedidos</th><th>Estado</th><th>Acción</th></tr></thead><tbody>{data.members.map((m:any)=>{const grants=assigned(m),ids=grants.filter(id=>id!==ORDER_PERMISSION),orders=grants.includes(ORDER_PERMISSION);return <tr key={m.email}><td>{m.email}</td><td>{ids.map(id=>data.products.find((p:any)=>p.id===id)?.name||id).join(', ')}</td><td>{orders?'Permitido':'Sin acceso'}</td><td>{m.active?'Autorizado':'Revocado'}</td><td><button type="button" disabled={busy} onClick={()=>{setEmail(m.email);setProducts(ids);setManageOrders(orders);window.scrollTo({top:0,behavior:'smooth'})}}>Editar permisos</button>{m.active&&<button type="button" className="danger" disabled={busy} onClick={()=>onSave({email:m.email,products:ids,manageOrders:orders,active:false})}>Revocar acceso</button>}</td></tr>})}</tbody></table></div>
  <p className="muted">Las cuentas administradoras se configuran en el servidor con ADMIN_EMAILS. Revocar una cuenta invalida sus sesiones. Los códigos temporales requieren configurar un proveedor de correo.</p>
 </>;
}

