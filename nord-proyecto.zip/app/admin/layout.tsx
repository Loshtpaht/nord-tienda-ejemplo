import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Panel privado · NÓRD",
  description: "Acceso privado a la administración de NÓRD.",
  robots: { index: false, follow: false },
};
export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return children;
}
