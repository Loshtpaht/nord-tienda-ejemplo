const pages=['/','/legal/privacidad','/legal/terminos','/legal/cookies','/legal/reembolsos','/legal/negocio','/legal/imagenes'];
export function GET(request: Request) {
  const origin=new URL(request.url).origin;
  const body='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+pages.map(path=>'  <url><loc>'+origin+path+'</loc></url>').join('\n')+'\n</urlset>';
  return new Response(body,{headers:{'Content-Type':'application/xml; charset=utf-8','Cache-Control':'public, max-age=3600','X-Robots-Tag':'noindex, nofollow'}});
}
