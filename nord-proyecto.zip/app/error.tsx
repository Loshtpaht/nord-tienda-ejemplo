"use client";

export default function Error({ reset }: { error: Error; reset: () => void }) {
  return <main className="not-found-page" role="alert">
    <p className="eyebrow">NÓRD</p>
    <h1>No pudimos abrir esta página.</h1>
    <p>La conexión puede haberse interrumpido. Inténtalo de nuevo.</p>
    <button className="primary" onClick={reset}>Intentar de nuevo</button>
  </main>;
}
