---
name: "NÓRD"
description: "Ropa y fragancias de ejemplo, con una voz editorial sobria y controles claros."
colors:
  "bg": "#fff"
  "surface": "#f2f4f3"
  "ink": "#202623"
  "muted": "#626a66"
  "line": "#dce1de"
  "accent": "#193f32"
  "on-accent": "#fff"
  "accent-soft": "#e8eeeb"
  "danger": "#a02c2c"
  "dark-bg": "#141b18"
  "dark-surface": "#1c2520"
  "dark-ink": "#eef2ef"
  "dark-muted": "#b2bcb5"
  "dark-line": "#38443c"
  "dark-accent": "#a6d0ba"
  "dark-on-accent": "#14291e"
  "dark-accent-soft": "#293b31"
  "dark-danger": "#f2a09a"
  "control-line": "#7b857e"
  "dark-control-line": "#788b7e"
  "photo-ivory": "#ecebe6"
  "hero-copy": "#f1f4f2"
typography:
  display:
    fontFamily: "Outfit, Arial, sans-serif"
    fontSize: "clamp(38px,4.4vw,66px)"
    fontWeight: 500
    lineHeight: 1.06
    letterSpacing: "-.025em"
  headline:
    fontFamily: "Outfit, Arial, sans-serif"
    fontSize: "clamp(26px,2.7vw,40px)"
    fontWeight: 500
    lineHeight: 1.15
    letterSpacing: "-.025em"
  brand-display:
    fontFamily: "Outfit, Arial, sans-serif"
    fontSize: "clamp(40px,5.6vw,74px)"
    fontWeight: 500
    lineHeight: 1.05
    letterSpacing: "-.025em"
  admin-title:
    fontFamily: "Outfit, Arial, sans-serif"
    fontSize: "34px"
    fontWeight: 500
    lineHeight: 1.5
    letterSpacing: "-.025em"
  product-title:
    fontFamily: "Outfit, Arial, sans-serif"
    fontSize: "17px"
    fontWeight: 500
    lineHeight: 1.5
  body:
    fontFamily: "Outfit, Arial, sans-serif"
    fontSize: "16px"
    fontWeight: 400
    lineHeight: 1.5
  label:
    fontFamily: "Outfit, Arial, sans-serif"
    fontSize: "14px"
    fontWeight: 400
    lineHeight: 1.5
  caption:
    fontFamily: "Outfit, Arial, sans-serif"
    fontSize: "13px"
    lineHeight: 1.5
  wordmark:
    fontFamily: "Outfit, Arial, sans-serif"
    fontSize: "30px"
    fontWeight: 600
    lineHeight: 1
    letterSpacing: ".17em"
rounded:
  "square": "0"
  "tab": "2px"
  "control": "3px"
  "notice": "5px"
  "dialog": "12px"
  "circle": "50%"
spacing:
  "6": "6px"
  "7": "7px"
  "8": "8px"
  "10": "10px"
  "12": "12px"
  "14": "14px"
  "16": "16px"
  "18": "18px"
  "20": "20px"
  "22": "22px"
  "24": "24px"
  "25": "25px"
  "28": "28px"
  "30": "30px"
  "32": "32px"
  "36": "36px"
  "40": "40px"
  "42": "42px"
  "45": "45px"
  "48": "48px"
  "60": "60px"
components:
  button-primary:
    backgroundColor: "{colors.accent}"
    textColor: "{colors.on-accent}"
    rounded: "{rounded.control}"
    padding: "13px 24px"
    height: "49px"
  button-secondary:
    backgroundColor: "{colors.bg}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "10px 18px"
    height: "44px"
  button-text:
    backgroundColor: "transparent"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "0"
    height: "36px"
  button-icon:
    backgroundColor: "transparent"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "0"
    height: "44px"
    width: "44px"
  input:
    backgroundColor: "{colors.bg}"
    textColor: "{colors.ink}"
    typography: "{typography.body}"
    rounded: "{rounded.control}"
    padding: "10px 12px"
    height: "44px"
    width: "100%"
  chip-filter-active:
    backgroundColor: "{colors.accent-soft}"
    textColor: "{colors.accent}"
    rounded: "{rounded.tab}"
    padding: "9px 14px"
    height: "44px"
  product-photo:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.square}"
    padding: "0"
    width: "100%"
  order-card:
    textColor: "{colors.ink}"
    padding: "24px 0"
  navigation:
    backgroundColor: "{colors.bg}"
    textColor: "{colors.ink}"
    height: "56px"
    padding: "0 6%"
  modal:
    backgroundColor: "{colors.bg}"
    textColor: "{colors.ink}"
    rounded: "{rounded.dialog}"
    padding: "28px"
    width: "min(560px,calc(100% - 32px))"
---

# Design System: NÓRD

## Overview

**Creative North Star: "Menos ruido. Más tú."**

NÓRD expresa una tienda editorial sobria: fotografía amplia, Outfit local, verde bosque y superficies claras. La campaña presenta el carácter de la marca; el catálogo y el panel reducen la decoración para que producto, precio, existencias y acciones se lean con claridad.

El mundo aprobado se describe como blanco cálido. La implementación actual utiliza blanco puro para el fondo general; el marfil pertenece a las fotografías de fragancias. El modo oscuro conserva la jerarquía mediante colores semánticos alternativos. Los movimientos son breves y el recorrido de la campaña es sutil; la preferencia de movimiento reducido elimina animaciones y desplazamientos.

**Key Characteristics:**

- Fotografía editorial y productos con información visible.
- Una sola familia tipográfica local: Outfit.
- Verde semántico, superficies planas y separadores discretos.
- Modo oscuro y estados de foco visibles.
- Movimiento CSS breve y reducción de movimiento respetada.

## Colors

El verde organiza acciones y selección; los neutros dejan que la fotografía lleve el carácter editorial. El frontmatter es la fuente normativa de valores.

### Primary

- **Verde bosque — accent:** acciones principales, disponibilidad, selección y foco en el tema claro.
- **Verde suave — accent-soft:** pestañas seleccionadas, estados y propuestas confirmadas.
- **Tinta sobre verde — on-accent:** contraste del texto dentro de acciones principales.
- **Verde claro — dark-accent:** acción y foco en el tema oscuro, acompañado por dark-on-accent y dark-accent-soft.

### Neutral

- **Blanco de página — bg:** fondo general claro. Aunque el mundo aprobado se llama blanco cálido, el valor real es blanco puro.
- **Gris suave verdoso — surface:** franjas, asistente, fondos de carga y superficies de apoyo.
- **Tinta verde — ink:** texto principal; **gris legible — muted:** texto de apoyo.
- **Separador — line:** líneas de catálogo, navegación, tablas y pedidos.
- **Borde de control — control-line:** borde más marcado para campos, buscador y selector de productos autorizados; proviene de la última regla del CSS.
- **Neutros oscuros — dark-bg, dark-surface, dark-ink, dark-muted, dark-line y dark-control-line:** sustituyen sus pares claros bajo data-theme=dark.
- **Marfil fotográfico — photo-ivory:** fondo de fragancias, conservado en ambos temas.
- **Texto de campaña — hero-copy:** apoyo sobre la fotografía. Los títulos de campaña permanecen blancos.

El rojo danger y su par dark-danger son señales funcionales de error y agotado, no un segundo acento de marca. La selección de texto usa accent y on-accent.

**The Semantic Theme Rule.** Usa los colores semánticos para controles y superficies. La campaña conserva su botón verde bosque con texto blanco en ambos temas.

## Typography

**Display Font:** Outfit (Arial, sans-serif como respaldo).
**Body Font:** Outfit (Arial, sans-serif como respaldo).

La fuente variable se sirve desde /fonts/outfit.ttf; su rango declarado es 100–900 y font-display es swap. La jerarquía combina títulos de peso medio, cuerpo regular y etiquetas compactas. No hay una escala de razón única ni una fuente monoespaciada independiente.

### Hierarchy

- **Display:** título de campaña; usa el rol display del frontmatter. En móvil se fija a 42px y un ancho de 340px.
- **Headline:** títulos de sección; el texto equilibra líneas con text-wrap:balance. Destacados usa 32px desde 768px; en móvil, 28px.
- **Brand display:** declaración editorial; pasa a 48px en móvil.
- **Admin title:** nombre de vista del panel; pasa a 30px en móvil.
- **Product title:** nombre de producto de peso medio; pasa a 16px en móvil.
- **Body:** lectura y controles; los párrafos generales tienen un máximo de 70ch. La lectura legal aumenta su interlineado a 1.7.
- **Label / Caption:** etiquetas de formulario y datos secundarios, sin imponer mayúsculas.
- **Wordmark:** nombre tipográfico con espaciado abierto; pasa a 26px en el encabezado móvil.

Precios, cantidades, tablas y totales usan font-variant-numeric:tabular-nums.

**The Outfit Rule.** Conserva Outfit local para títulos, cuerpo, etiquetas y controles; usa Arial y sans-serif como respaldo.

## Layout

La tienda usa secciones centradas de hasta 1600px, márgenes laterales de 6% y relleno vertical de 48px. En móvil los laterales son 5% y el relleno vertical 42px. Destacados reduce su relleno superior a 12px en escritorio.

El catálogo tiene cuatro columnas, separación vertical de 36px y horizontal de 24px. A 1024px o menos baja a tres columnas; destacados conserva cuatro. A 767px o menos ambos tienen dos columnas, con separaciones de 26px y 14px. Las fotografías generales son 4:5; destacados usa 4:3 desde 768px. No hay un tamaño mínimo de pantalla adicional declarado en CSS.

El encabezado es sticky y mide 56px en escritorio y 74px en móvil. La navegación móvil abre debajo del encabezado, permite envolver enlaces y conserva controles de 44px. El buscador pasa a ancho completo y los filtros se desplazan horizontalmente.

El panel tiene una columna lateral de 240px y contenido flexible de hasta 1450px, con relleno de 45px y 5%. La lateral baja a 190px a 1024px; en móvil se sitúa arriba, la navegación es horizontal y el contenido usa 30px y 5%. Los formularios de dos columnas y el detalle de producto pasan a una columna. Las tablas mantienen desplazamiento horizontal.

Los diálogos limitan ancho y altura al viewport: normal de hasta 560px, ancho de hasta 900px, margen exterior de 16px por lado, y altura máxima de 90dvh (92dvh móvil). Los documentos legales tienen un contenedor de 820px.

El espaciado documentado es un inventario de distancias reutilizadas, no una escala matemática nueva. Mantén las diferencias de densidad entre catálogo, formularios y panel.

## Elevation & Depth

La base es plana: fondos tonales, líneas y aire separan regiones. Las sombras indican capas superpuestas y acciones flotantes.

### Shadow Vocabulary

- **Contacto flotante:** 0 8px 20px #0002.
- **Aviso temporal:** 0 8px 28px #0003.
- **Diálogo:** 0 20px 80px #0004.
- **Preferencias de almacenamiento:** 0 10px 45px rgba(0,0,0,.2).

El backdrop del diálogo es #0a151bb3. La campaña utiliza un degradado oscuro desde rgba(8,19,12,.6) a transparente; en móvil la base pasa a .75. Son capas funcionales de legibilidad, no fondos de tarjeta.

**The Floating Layer Rule.** Reserva las sombras para diálogos, avisos y controles flotantes; las listas de productos, inventario y pedidos se separan con espacio y líneas.

## Shapes

Fotografías rectangulares sin radio y bordes mínimos definen el catálogo. Los controles tienen esquinas discretas; filtros, avisos y diálogos utilizan los radios normativos del frontmatter. El círculo se reserva para el contador del carrito y el contacto flotante.

Los bordes normales son de 1px. El foco común usa outline de 2px en accent y separación de 4px; las excepciones existentes son el campo dentro del buscador (1px) y botones del panel de preferencias (2px). No sustituyas el indicador visible por una sombra.

## Components

### Buttons

Acciones compactas de peso medio, con texto e icono de trazo fino.

- **Primary:** par accent/on-accent, relleno del frontmatter y altura mínima de 49px. Hover aumenta brightness a 1.1; el botón de campaña fija el verde bosque y blanco en ambos temas.
- **Secondary:** fondo de página, borde line, altura mínima de 44px.
- **Text:** sin borde ni fondo, alineación inicial y altura mínima de 36px.
- **Icon:** 44px cuadrados, sin borde; hover de puntero fino usa surface.
- **States:** pulsación escala a .98; deshabilitado usa opacidad .5 y no escala. Fondo, texto y borde transicionan en 160ms ease; transform en 130ms con --ease.

Las alturas del frontmatter para botones y campos son mínimos CSS, no alturas rígidas que deban recortar texto.

### Chips

Los filtros son botones de categoría con selección suave: accent-soft y accent, sin borde. Sin seleccionar usan muted y fondo transparente. Mantienen aria-pressed. El estado de pedido usa el mismo par de selección y el radio de control, con relleno de 6px 12px.

### Cards / Containers

La tarjeta de producto integra fotografía, nombre, categoría, precio y disponibilidad, sin contenedor elevado. La fotografía tiene fondo surface; las fragancias pueden usar marfil. La acción Ver producto aparece en hover y foco bajo puntero fino, y permanece visible en móvil.

Las listas de inventario y pedidos son filas separadas con line. El asistente usa surface y relleno de 28px (20px móvil). No existe una tarjeta genérica de alto radio y sombra como base del catálogo.

### Inputs / Fields

Campos y selector comparten fondo bg, texto ink, borde control-line, radio de control, relleno de 10px 12px y altura mínima de 44px. El buscador es un contenedor con borde y campo interno sin borde. Los placeholders usan muted con opacidad completa.

Checkboxes y radios visibles tienen 18px y accent-color. El error combina danger con surface; éxito combina accent con accent-soft. ErrorBox usa role=alert y los avisos de confirmación usan role=status.

### Navigation

El encabezado equilibra marca, navegación y controles. Los enlaces/botones tienen separación de 32px; baja a 22px a 1024px. Inicio conserva un subrayado verde de 2px. El panel indica su vista activa mediante accent-soft y accent.

### Modal

El componente compartido utiliza dialog nativo con showModal, cierra con Escape y desde el backdrop, y bloquea el scroll de fondo. Contiene título y control de cierre de 44px. El estilo efectivo usa dialog-enter de 220ms con cubic-bezier(.16,1,.3,1); backdrop-enter dura 180ms ease-out. Existe una regla modal-in anterior que queda sustituida cuando no se solicita movimiento reducido.

### Campaign and feedback motion

El scroll de campaña actualiza una variable CSS mediante rAF; la foto se desplaza hasta 35px y su escala cambia de 1.025 a 1.01, mientras el texto se desplaza hasta -10px. La imagen de producto usa un zoom a 1.035 de 600ms. La acción de tarjeta entra en 220ms y funde en 200ms. El aviso entra en 200ms con la curva del diálogo.

Con prefers-reduced-motion:reduce, el scroll es inmediato, las animaciones desaparecen y las transiciones duran .01ms. La campaña elimina transform y will-change, y no instala su actualización de scroll. El contenido está visible desde el inicio.

## Do's and Don'ts

### Do:

- **Do** mantener los pares semánticos de color en ambos temas.
- **Do** usar Outfit local y cifras tabulares para precios, cantidades y totales.
- **Do** conservar los indicadores de foco visibles y las acciones visibles en tarjetas móviles.
- **Do** respetar prefers-reduced-motion en las transiciones y el movimiento de campaña.
- **Do** distinguir datos de demostración y solicitudes pendientes en el texto visible.

### Don't:

- **Don't** convertir las tarjetas de catálogo o las filas de inventario en paneles elevados.
- **Don't** aplicar el modo oscuro a las fotografías alterando su color o el fondo marfil de fragancias.
- **Don't** ocultar el contenido inicial detrás de animaciones de entrada.
- **Don't** mostrar reseñas, métricas comerciales o confirmaciones de compra no verificadas.
