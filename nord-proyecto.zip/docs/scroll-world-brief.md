# Brief futuro · Scroll World · NÓRD

Estado: pospuesto por el usuario. Implementación actual con CSS, sin generación de video ni servicio de pago. Este documento no autoriza cargos ni una integración futura.

Objetivo: una entrada editorial que presente ropa, fragancias y accesorios y conduzca rápidamente al catálogo. Conservar la tienda aprobada: blanco cálido, verde bosque, piedra clara, luz natural y Outfit. El movimiento acompaña el recorrido; no bloquea la compra, el teclado ni el acceso al panel.

Escena propuesta, 6–8 segundos: patio mediterráneo sobrio de piedra caliza marfil, vegetación de olivo con sombra suave; dos modelos ficticios, mujer con ropa clara y hombre con camisa oliva, postura relajada. La cámara avanza lentamente con una leve deriva lateral, sin cambios bruscos ni zoom dramático. La tela responde a una brisa muy ligera. Composición con espacio tranquilo abajo a la izquierda para “Lo esencial, a tu manera.” y “Explorar catálogo”. La fotografía conserva textura realista y luz de tarde coherente; tonos cálidos sin filtro naranja, negros naturales, ningún brillo artificial, textos o logotipos inventados dentro del video. No utilizar celebridades ni imitar una campaña concreta.

Secuencia al desplazar: primer tramo presenta la escena sin esconder el mensaje; segundo tramo cambia suavemente la proximidad y las sombras, el texto permanece legible y el CTA utilizable; tercer tramo da paso a Hombres, Mujeres y Todo y a los destacados con un corte editorial simple. Los productos y su interfaz permanecen HTML real, no se incrustan en los fotogramas.

Imágenes de fragancias: no animar marcas ni falsificar su presentación. Usar fotografía autorizada del producto comercial concreto o las recreaciones de demostración identificadas. El fondo marfil evita que los frascos claros se confundan con la página y conserva bordes/sombras. No añadir afirmaciones de autenticidad, reseñas, exclusividad ni distribución oficial.

Responsive: encuadre específico para 390 px, centrado en el modelo de la izquierda, con espacio inferior para texto y botón. Escritorio conserva ambas figuras completas. Entregar poster estático y video optimizado con tamaños adecuados; la versión móvil debe evitar descargas grandes. Nada de video en catálogo, checkout, políticas o panel.

Accesibilidad/rendimiento: reduce-motion muestra solo el poster, sin scroll interceptado ni pinning obligatorio. No bloquear la lectura hasta terminar una animación. Alt del poster, texto semántico, contraste AA, controles accesibles por teclado. Cargar el poster primero; video diferido cuando corresponda. Fallback estático ante falla, ahorro de datos o dispositivo lento.

Antes de integrar: confirmar servicio y costo, licencias de insumos/salida, formato y peso de archivos, condiciones de almacenamiento del proveedor y permisos de la tienda. Validar el resultado visual junto al diseño actual en móvil y escritorio, incluyendo carrito y header fijos. El inventario, pedidos y acceso privado no dependen de este efecto.
