# NÓRD
<!-- impeccable:product-schema 1 -->
## Platform
web
## Stack
React, Vinext, servidor Cloudflare Workers, D1 y R2. Elección recomendada aprobada por el usuario.
## Users
Clientes que exploran y piden productos desde celular o computadora; personal autorizado que administra catálogo y entrega.
## Product Purpose
Pedidos sin pago en línea, con resumen, existencias reales, reservas atómicas, correos pendientes de confirmación y coordinación directa.
## Capabilities and Constraints
Catálogo editable, categorías extensibles, variantes, imágenes, carrito, auditoría de inventario, asistente con propuesta antes de aplicar, estados de pedidos, cancelación y vencimiento. No prometer compra o entrega confirmada al recibir un pedido.
## Brand Commitments
NÓRD, ropa y fragancias de ejemplo, aprobado por el usuario. Todo dato de demostración debe identificarse. Nombre, logo, contactos y catálogo reemplazables.
## Evidence on Hand
No hay datos comerciales reales ni credenciales de correo o IA. Usar contenido de ejemplo.
## Product Principles
Existencias coherentes, privacidad del cliente, confirmar cambios de inventario, interfaz accesible y operación sin código.
