# NÓRD · tienda y panel

Mode: Persuade (inicio), Operate (catálogo, carrito y panel), Read (políticas).

El usuario aprobó explícitamente la composición de `.impeccable/mocks/decision/approved.png`: fotografía editorial de modelos ficticios, blanco cálido, verde bosque, tipografía sobria, navegación Hombres/Mujeres y productos destacados. Preservar ese mundo. Outfit variable local es la voz tipográfica. No volver a abrir una selección de estilos.

Primer viewport: entender que NÓRD vende ropa y fragancias de ejemplo, ver campaña y CTA Explorar catálogo, accesos Hombres/Mujeres/Todo y comienzo de destacados. Responsive desde 390 px hasta escritorio; modo oscuro solicitado.

Momento de movimiento: desplazamiento muy sutil de la campaña al recorrer la página, con CSS y rAF limitado. Contenido visible desde el inicio. Estados y diálogos 180–220 ms, ease-out; respetar reduced-motion. El usuario pospuso Scroll World y cualquier video de pago.

Cambios aprobados después del comp: catálogo con cuatro perfumes reales de ejemplo; dos fotografías femeninas atribuidas y dos recreaciones masculinas con IA, expresamente etiquetadas no oficiales. Fondo marfil de Armani/BOSS y pantalón coral. Eliminar Perfume A e Intense también del inventario. Accesorios aprobados, conservarlos. No reseñas falsas, métricas comerciales ni reclamos no verificados.

Panel: administrador de tienda, no rol exclusivo del desarrollador. Acceso ChatGPT autorizado y código de correo opcional (10 minutos, un uso, cinco errores; correo externo pendiente). Permiso proveedor solo a productos asignados y registro de sus ajustes; sin clientes, pedidos ni configuración. Rol administrador puede operar pedidos y catálogo.

Checkout: nombre, correo, dirección/zona y teléfono opcional. Consentimientos sin premarcar, resumen, envío formal separado de WhatsApp. No cobra ni promete confirmación comercial o entrega. Stock se reserva atómicamente. Políticas separadas para El Salvador; datos comerciales todavía pendientes.

El sitio completo es servidor + D1 + R2. GitHub Pages y HTML son copias visuales estáticas identificadas, sin simular reservas, correo o acceso privado. Ninguna contraseña, código, correo privado de las cuentas autorizadas, token o registro de clientes se incluye en el repositorio.
