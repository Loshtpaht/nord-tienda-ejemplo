CREATE TABLE `audit` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`variant_id` text NOT NULL,
	`before_quantity` integer NOT NULL,
	`after_quantity` integer NOT NULL,
	`actor` text NOT NULL,
	`action` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `order_lines` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`order_id` integer NOT NULL,
	`variant_id` text NOT NULL,
	`name` text NOT NULL,
	`label` text NOT NULL,
	`quantity` integer NOT NULL,
	`price` integer NOT NULL,
	FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`variant_id`) REFERENCES `variants`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `order_audit` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`order_id` integer NOT NULL,
	`before_status` text NOT NULL,
	`after_status` text NOT NULL,
	`actor` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`order_key` text NOT NULL,
	`payload_hash` text NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`phone` text NOT NULL,
	`address` text NOT NULL,
	`status` text DEFAULT 'recibido' NOT NULL,
	`expires` integer NOT NULL,
	`created` integer NOT NULL,
	`actor` text DEFAULT 'cliente' NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `orders_order_key_unique` ON `orders` (`order_key`);--> statement-breakpoint
CREATE TABLE `outbox` (
	`id` text PRIMARY KEY NOT NULL,
	`order_id` integer NOT NULL,
	`kind` text NOT NULL,
	`recipient` text NOT NULL,
	`subject` text NOT NULL,
	`body` text NOT NULL,
	`state` text DEFAULT 'pendiente' NOT NULL,
	`provider_id` text,
	`attempts` integer DEFAULT 0 NOT NULL,
	`next_attempt` integer DEFAULT 0 NOT NULL,
	`lease` integer DEFAULT 0 NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`description` text NOT NULL,
	`category` text NOT NULL,
	`price` integer NOT NULL,
	`images` text NOT NULL,
	`featured` integer DEFAULT 0 NOT NULL,
	`active` integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `proposals` (
	`id` text PRIMARY KEY NOT NULL,
	`actor` text NOT NULL,
	`data` text NOT NULL,
	`expires` integer NOT NULL,
	`applied` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `rate_limits` (
	`id` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`id` integer PRIMARY KEY NOT NULL,
	`data` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `variants` (
	`id` text PRIMARY KEY NOT NULL,
	`product_id` text NOT NULL,
	`label` text NOT NULL,
	`quantity` integer NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`actor` text DEFAULT 'sistema' NOT NULL,
	`action` text DEFAULT 'manual' NOT NULL,
	FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE no action ON DELETE no action
);
CREATE INDEX order_lines_order_idx ON order_lines(order_id);
--> statement-breakpoint
CREATE UNIQUE INDEX order_lines_variant_unique ON order_lines(order_id,variant_id);
--> statement-breakpoint
CREATE INDEX outbox_retry_idx ON outbox(state,next_attempt,lease);
--> statement-breakpoint
CREATE TRIGGER variant_insert_guard BEFORE INSERT ON variants WHEN NEW.quantity<0 OR typeof(NEW.quantity)!='integer' BEGIN SELECT RAISE(ABORT,'STOCK_INVALID'); END;
--> statement-breakpoint
CREATE TRIGGER variant_update_guard BEFORE UPDATE OF quantity ON variants WHEN NEW.quantity<0 OR typeof(NEW.quantity)!='integer' BEGIN SELECT RAISE(ABORT,'STOCK_INVALID'); END;
--> statement-breakpoint
CREATE TRIGGER stock_audit AFTER UPDATE OF quantity ON variants WHEN NEW.quantity!=OLD.quantity BEGIN
 INSERT INTO audit(variant_id,before_quantity,after_quantity,actor,action,created) VALUES(NEW.id,OLD.quantity,NEW.quantity,NEW.actor,NEW.action,unixepoch());
END;
--> statement-breakpoint
CREATE TRIGGER variant_creation_audit AFTER INSERT ON variants BEGIN
 INSERT INTO audit(variant_id,before_quantity,after_quantity,actor,action,created) VALUES(NEW.id,0,NEW.quantity,NEW.actor,NEW.action,unixepoch());
END;
--> statement-breakpoint
CREATE TRIGGER reserve_before BEFORE INSERT ON order_lines BEGIN
 SELECT CASE WHEN NEW.quantity<1 OR typeof(NEW.quantity)!='integer' THEN RAISE(ABORT,'STOCK_INVALID') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM orders WHERE id=NEW.order_id AND status='recibido' AND expires>unixepoch()) THEN RAISE(ABORT,'ORDER_INVALID') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM variants v JOIN products p ON p.id=v.product_id WHERE v.id=NEW.variant_id AND v.quantity>=NEW.quantity AND p.active=1) THEN RAISE(ABORT,'STOCK_UNAVAILABLE') END;
 SELECT CASE WHEN NEW.price!=(SELECT p.price FROM variants v JOIN products p ON p.id=v.product_id WHERE v.id=NEW.variant_id) THEN RAISE(ABORT,'PRICE_CHANGED') END;
END;
--> statement-breakpoint
CREATE TRIGGER reserve_after AFTER INSERT ON order_lines BEGIN
 UPDATE variants SET quantity=quantity-NEW.quantity,revision=revision+1,actor='cliente',action='reserva pedido '||NEW.order_id WHERE id=NEW.variant_id;
END;
--> statement-breakpoint
CREATE TRIGGER immutable_line_update BEFORE UPDATE ON order_lines BEGIN SELECT RAISE(ABORT,'IMMUTABLE_ORDER_LINE'); END;
--> statement-breakpoint
CREATE TRIGGER immutable_line_delete BEFORE DELETE ON order_lines BEGIN SELECT RAISE(ABORT,'IMMUTABLE_ORDER_LINE'); END;
--> statement-breakpoint
CREATE TRIGGER order_transition_guard BEFORE UPDATE OF status ON orders WHEN NEW.status!=OLD.status BEGIN
 SELECT CASE WHEN NOT ((OLD.status='recibido' AND NEW.status IN('confirmado','cancelado')) OR (OLD.status='confirmado' AND NEW.status IN('en preparación','cancelado')) OR (OLD.status='en preparación' AND NEW.status IN('en camino','cancelado')) OR (OLD.status='en camino' AND NEW.status IN('entregado','cancelado'))) THEN RAISE(ABORT,'STATUS_INVALID') END;
 SELECT CASE WHEN OLD.status='recibido' AND NEW.status='confirmado' AND OLD.expires<=unixepoch() THEN RAISE(ABORT,'ORDER_EXPIRED') END;
END;
--> statement-breakpoint
CREATE TRIGGER release_cancelled AFTER UPDATE OF status ON orders WHEN NEW.status='cancelado' AND OLD.status!='cancelado' BEGIN
 UPDATE variants SET quantity=quantity+(SELECT l.quantity FROM order_lines l WHERE l.order_id=NEW.id AND l.variant_id=variants.id),revision=revision+1,actor=NEW.actor,action='devolución pedido '||NEW.id WHERE id IN(SELECT variant_id FROM order_lines WHERE order_id=NEW.id);
END;
--> statement-breakpoint
CREATE TRIGGER status_audit AFTER UPDATE OF status ON orders WHEN OLD.status!=NEW.status BEGIN
 INSERT INTO order_audit(order_id,before_status,after_status,actor,created) VALUES(NEW.id,OLD.status,NEW.status,NEW.actor,unixepoch());
END;

