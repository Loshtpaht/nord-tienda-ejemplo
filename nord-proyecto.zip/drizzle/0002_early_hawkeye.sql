CREATE TABLE `access_members` (
	`email` text PRIMARY KEY NOT NULL,
	`products` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`updated` integer NOT NULL,
	`actor` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `auth_challenges` (
	`id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`code_hash` text NOT NULL,
	`expires` integer NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`consumed` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE `auth_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`expires` integer NOT NULL,
	`created` integer NOT NULL
);
