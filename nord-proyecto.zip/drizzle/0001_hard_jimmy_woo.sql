ALTER TABLE `orders` ADD `policy_version` text DEFAULT 'legacy' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `consented_at` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `terms_accepted` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `privacy_accepted` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `transfers_accepted` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `anonymized_at` integer DEFAULT 0 NOT NULL;