CREATE INDEX `orders_status_expiry_idx` ON `orders` (`status`,`expires`);--> statement-breakpoint
CREATE INDEX `variants_product_idx` ON `variants` (`product_id`);